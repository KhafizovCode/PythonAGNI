initial_level = float(input())  # Начальный уровень, см
volume_added = float(input())   # Поступивший объём, м³
coefficient = float(input())    # Постоянный коэффициент объёма, м³/см
new_level = initial_level + (volume_added / coefficient)
print(new_level)