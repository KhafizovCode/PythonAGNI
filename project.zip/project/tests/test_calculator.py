import unittest

from app.calculator import add, subtract, multiply, divide, power, calculate


class TestAdd(unittest.TestCase):
    def test_positive(self):
        self.assertEqual(add(2, 3), 5)

    def test_negative(self):
        self.assertEqual(add(-2, -3), -5)

    def test_float(self):
        self.assertAlmostEqual(add(0.1, 0.2), 0.3)


class TestSubtract(unittest.TestCase):
    def test_positive(self):
        self.assertEqual(subtract(10, 4), 6)

    def test_negative_result(self):
        self.assertEqual(subtract(4, 10), -6)


class TestMultiply(unittest.TestCase):
    def test_positive(self):
        self.assertEqual(multiply(6, 7), 42)

    def test_by_zero(self):
        self.assertEqual(multiply(5, 0), 0)

    def test_negative(self):
        self.assertEqual(multiply(-3, 4), -12)


class TestDivide(unittest.TestCase):
    def test_simple(self):
        self.assertEqual(divide(20, 4), 5)

    def test_float_result(self):
        self.assertEqual(divide(7, 2), 3.5)

    def test_by_zero(self):
        with self.assertRaises(ZeroDivisionError):
            divide(5, 0)


class TestPower(unittest.TestCase):
    def test_positive_exponent(self):
        self.assertEqual(power(2, 10), 1024)

    def test_zero_exponent(self):
        self.assertEqual(power(5, 0), 1)

    def test_negative_exponent(self):
        self.assertEqual(power(2, -2), 0.25)

    def test_fractional_exponent(self):
        self.assertEqual(power(9, 0.5), 3)

    def test_zero_to_negative(self):
        with self.assertRaises(ZeroDivisionError):
            power(0, -1)

    def test_negative_base_fractional_exponent(self):
        with self.assertRaises(ValueError):
            power(-4, 0.5)


class TestCalculate(unittest.TestCase):
    def test_all_operations(self):
        self.assertEqual(calculate("+", 2, 3), 5)
        self.assertEqual(calculate("-", 2, 3), -1)
        self.assertEqual(calculate("*", 2, 3), 6)
        self.assertEqual(calculate("/", 6, 3), 2)
        self.assertEqual(calculate("**", 2, 3), 8)
        self.assertEqual(calculate("^", 2, 3), 8)

    def test_unknown_operation(self):
        with self.assertRaises(ValueError):
            calculate("%", 2, 3)


if __name__ == "__main__":
    unittest.main()
