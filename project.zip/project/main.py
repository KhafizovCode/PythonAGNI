"""Консольный калькулятор. Запуск: python main.py"""

from app.calculator import calculate


def read_number(prompt):
    while True:
        try:
            return float(input(prompt).replace(",", "."))
        except ValueError:
            print("Введите число.")


def main():
    print("Калькулятор. Действия: + - * / ** (возведение в степень, можно ^)")
    while True:
        operation = input("Действие (или q для выхода): ").strip()
        if operation.lower() == "q":
            break

        a = read_number("Первое число: ")
        b = read_number("Второе число (для степени это показатель): ")

        try:
            result = calculate(operation, a, b)
            print(f"Результат: {result}")
        except (ValueError, ZeroDivisionError) as error:
            print(f"Ошибка: {error}")


if __name__ == "__main__":
    main()
