"""Основные операции калькулятора."""


def add(a, b):
    """Сложение."""
    return a + b


def subtract(a, b):
    """Вычитание."""
    return a - b


def multiply(a, b):
    """Умножение."""
    return a * b


def divide(a, b):
    """Деление. При делении на ноль выбрасывает ZeroDivisionError."""
    if b == 0:
        raise ZeroDivisionError("Деление на ноль невозможно")
    return a / b


def power(a, b):
    """Возведение a в степень b (степень задаётся пользователем с клавиатуры)."""
    if a == 0 and b < 0:
        raise ZeroDivisionError("Ноль нельзя возводить в отрицательную степень")
    if a < 0 and b != int(b):
        raise ValueError("Отрицательное число нельзя возводить в дробную степень")
    return a ** b


OPERATIONS = {
    "+": add,
    "-": subtract,
    "*": multiply,
    "/": divide,
    "**": power,
    "^": power,
}


def calculate(operation, a, b):
    """Выполняет операцию по её знаку: + - * / ** (или ^)."""
    if operation not in OPERATIONS:
        raise ValueError(f"Неизвестная операция: {operation}")
    return OPERATIONS[operation](a, b)
